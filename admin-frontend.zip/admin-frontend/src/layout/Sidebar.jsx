import {
  LayoutDashboard,
  FolderTree,
  Building2,
  Layers3,
  Users,
  FolderKanban,
  Video,
  ShieldCheck,
  MessageSquareQuote,
  X,
  User2Icon
} from "lucide-react";
import { NavLink } from "react-router-dom";
const menus = [
  { title: "Dashboard", icon: LayoutDashboard, path: "/" },
  { title: "Main Video", icon: Video, path: "/video" },
  { title: "Categories", icon: FolderTree, path: "/categories" },
  { title: "Sub Categories", icon: Layers3, path: "/sub-categories" },
  { title: "Companies", icon: Building2, path: "/companies" },
  { title: "Team", icon: Users, path: "/team" },
  { title: "Project", icon: FolderKanban, path: "/project" },
  { title: "Work", icon: Video, path: "/work" },
  { title: "Trusted By", icon: ShieldCheck, path: "/trustedBy" },
  { title: "Testimonials", icon: MessageSquareQuote, path: "/testimonials" }, 
  { title: "JobRoles", icon: User2Icon, path: "/job-roles" }, 
];
export default function Sidebar({ open, setOpen }) {
  return (
    <>
      {" "}
      {/* Mobile Overlay */}{" "}
      <div
        onClick={() => setOpen(false)}
        className={` fixed inset-0 bg-black/40 z-30 lg:hidden transition-opacity duration-300 ${open ? "opacity-100 visible" : "opacity-0 invisible pointer-events-none"} `}
      />{" "}
      {/* Sidebar */}{" "}
      <aside
        className={` fixed top-0 left-0 z-40 h-screen w-72 bg-white border-r border-gray-200 shadow-sm flex flex-col transform transition-transform duration-300 ease-in-out ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"} `}
      >
        {" "}
        {/* Header */}{" "}
        <div className="h-20 min-h-[80px] flex items-center justify-between px-6 border-b border-gray-200">
          {" "}
          <div>
            {" "}
            <h1 className="text-xl font-bold text-gray-900">
              {" "}
              SaySocial CMS{" "}
            </h1>{" "}
            <p className="text-xs text-gray-500 mt-1">
              {" "}
              Content Management{" "}
            </p>{" "}
          </div>{" "}
          {/* Mobile Close Button */}{" "}
          <button
            onClick={() => setOpen(false)}
            className=" lg:hidden p-2 rounded-lg text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition "
          >
            {" "}
            <X size={22} />{" "}
          </button>{" "}
        </div>{" "}
        {/* Navigation */}{" "}
        <nav className="flex-1 overflow-y-auto px-4 py-5">
          {" "}
          <p className="px-3 mb-3 text-xs font-semibold uppercase tracking-wider text-gray-400">
            {" "}
            Main Menu{" "}
          </p>{" "}
          <div className="space-y-1">
            {" "}
            {menus.map((menu) => {
              const Icon = menu.icon;
              return (
                <NavLink
                  key={menu.path}
                  to={menu.path}
                  end
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    ` group flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${isActive ? "bg-black text-white shadow-sm" : "text-gray-700 hover:bg-gray-100 hover:text-black"} `
                  }
                >
                  {" "}
                  <Icon size={20} strokeWidth={2} className="shrink-0" />{" "}
                  <span className="truncate"> {menu.title} </span>{" "}
                </NavLink>
              );
            })}{" "}
          </div>{" "}
        </nav>{" "}
        {/* Footer */}{" "}
        <div className="border-t border-gray-200 p-4">
          {" "}
          <div className="rounded-lg bg-gray-50 px-4 py-3">
            {" "}
            <p className="text-xs text-gray-400"> SaySocial CMS </p>{" "}
            <p className="text-sm font-medium text-gray-700">
              {" "}
              Admin Panel{" "}
            </p>{" "}
          </div>{" "}
        </div>{" "}
      </aside>{" "}
    </>
  );
}
